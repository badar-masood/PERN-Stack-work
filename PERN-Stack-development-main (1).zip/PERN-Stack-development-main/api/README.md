# Nodejs Restapi Postgresql
Lab on how to build NodeJS RESTFul API with PostgreSQL as a database
